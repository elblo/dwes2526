<?php
    echo phpinfo();
    
?>